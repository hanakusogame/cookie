function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.destroyed()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = option && option.modified ? option.modified : undefined;
          this._destroyedHandler = option && option.destroyed ? option.destroyed : undefined;
          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * Tweenが破棄されたかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.destroyed = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.destroyed() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j];

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 1,
      "./Easing": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 2,
      "./Timeline": 3,
      "./Tween": 4
    }],
    6: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Button =
      /** @class */
      function (_super) {
        __extends(Button, _super);

        function Button(scene, s, x, y, w, h) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          if (w === void 0) {
            w = 100;
          }

          if (h === void 0) {
            h = 50;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: w,
            height: h,
            x: x,
            y: y,
            touchable: true
          }) || this;

          _this.num = 0;

          _this.chkEnable = function (ev) {
            return true;
          };

          _this.pushEvent = function () {};

          if (Button.font == null) {
            Button.font = new g.DynamicFont({
              game: g.game,
              fontFamily: g.FontFamily.Monospace,
              size: 32
            });
          }

          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: w - 4,
            height: h - 4,
            cssColor: "white"
          });

          _this.append(base);

          _this.label = new g.Label({
            scene: scene,
            font: Button.font,
            text: s[0],
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: w - 4
          });
          _this.label.y = (h - 4 - _this.label.height) / 2;

          _this.label.modified();

          base.append(_this.label);

          _this.pointDown.add(function (ev) {
            if (!_this.chkEnable(ev)) return;
            base.cssColor = "gray";
            base.modified();

            if (s.length !== 1) {
              _this.num = (_this.num + 1) % s.length;
              _this.label.text = s[_this.num];

              _this.label.invalidate();
            }
          });

          _this.pointUp.add(function (ev) {
            base.cssColor = "white";
            base.modified();

            _this.pushEvent(ev);
          });

          return _this;
        }

        return Button;
      }(g.FilledRect);

      exports.Button = Button;
    }, {}],
    7: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Button_1 = require("./Button");

      var Config =
      /** @class */
      function (_super) {
        __extends(Config, _super);

        function Config(scene, x, y) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: 250,
            height: 250,
            x: x,
            y: y,
            touchable: true
          }) || this;

          _this.num = 0;
          _this.volumes = [0.5, 0.8];

          _this.chkEnable = function (ev) {
            return true;
          };

          var events = [_this.bgmEvent, _this.seEvent];
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.Monospace,
            size: 32
          });
          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: _this.width - 4,
            height: _this.height - 4,
            cssColor: "white"
          });

          _this.append(base);

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "設定",
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: 250
          }));
          var line = new g.FilledRect({
            scene: scene,
            x: 5,
            y: 30,
            width: 235,
            height: 2,
            cssColor: "#000000"
          });
          base.append(line);
          var strVol = ["ＢＧＭ", "効果音"];

          var _loop_1 = function _loop_1(i) {
            base.append(new g.Label({
              scene: scene,
              font: font,
              text: strVol[i],
              fontSize: 24,
              textColor: "black",
              x: 10,
              y: 50 + 50 * i
            }));
            var sprVol = new g.FrameSprite({
              scene: scene,
              src: scene.assets["volume"],
              width: 32,
              height: 32,
              x: 90,
              y: 50 + 50 * i,
              frames: [0, 1]
            });
            base.append(sprVol);
            var baseVol = new g.E({
              scene: scene,
              x: 130,
              y: 50 + 50 * i,
              width: 110,
              height: 32,
              touchable: true
            });
            base.append(baseVol);
            var lineVol = new g.FilledRect({
              scene: scene,
              x: 0,
              y: 13,
              width: 110,
              height: 6,
              cssColor: "gray"
            });
            baseVol.append(lineVol);
            var cursorVol = new g.FilledRect({
              scene: scene,
              x: 110 * this_1.volumes[i] - 7,
              y: 0,
              width: 15,
              height: 32,
              cssColor: "#000000"
            });
            baseVol.append(cursorVol);
            var flgMute = false;
            baseVol.pointMove.add(function (e) {
              var posX = e.point.x + e.startDelta.x;
              if (posX < 7) posX = 7;
              if (posX > 103) posX = 103;
              cursorVol.x = posX - 7;
              cursorVol.modified();
              flgMute = posX - 7 === 0;
            });
            baseVol.pointUp.add(function (e) {
              if (flgMute) {
                sprVol.frameNumber = 1;
              } else {
                sprVol.frameNumber = 0;
              }

              sprVol.modified();
              _this.volumes[i] = cursorVol.x / 110;

              if (i === 0 && _this.bgmEvent !== undefined) {
                _this.bgmEvent(_this.volumes[i]);
              }
            });
          };

          var this_1 = this;

          for (var i = 0; i < 2; i++) {
            _loop_1(i);
          }

          var colors = ["green", "gray", "black", "white", "navy"];
          var colorNum = 0; //背景色

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "背景色",
            fontSize: 24,
            textColor: "black",
            x: 10,
            y: 150
          }));
          base.append(new g.FilledRect({
            scene: scene,
            x: 130,
            y: 150,
            width: 110,
            height: 40,
            cssColor: "#000000"
          }));
          var sprColor = new g.FilledRect({
            scene: scene,
            x: 132,
            y: 152,
            width: 106,
            height: 36,
            cssColor: colors[colorNum],
            touchable: true
          });
          base.append(sprColor);
          sprColor.pointDown.add(function (e) {
            colorNum = (colorNum + 1) % colors.length;
            sprColor.cssColor = colors[colorNum];
            sprColor.modified();

            if (_this.colorEvent !== undefined) {
              _this.colorEvent(colors[colorNum]);
            }
          }); //ランキング表示

          var btnRank = new Button_1.Button(scene, ["ランキング"], 2, 198, 130, 45);
          base.append(btnRank);

          btnRank.pushEvent = function () {
            if (typeof window !== "undefined" && window.RPGAtsumaru) {
              window.RPGAtsumaru.experimental.scoreboards.display(1);
            }
          }; //閉じる


          var btnClose = new Button_1.Button(scene, ["閉じる"], 138, 198, 105, 45);
          base.append(btnClose);

          btnClose.pushEvent = function () {
            _this.hide();
          };

          return _this;
        }

        return Config;
      }(g.FilledRect);

      exports.Config = Config;
    }, {
      "./Button": 6
    }],
    8: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Config_1 = require("./Config");

      var Button_1 = require("./Button");

      var MainScene =
      /** @class */
      function (_super) {
        __extends(MainScene, _super);

        function MainScene(param) {
          var _this = this;

          param.assetIds = ["img_numbers_n", "img_numbers_n_red", "title", "start", "finish", "combo", "waku", "score", "time", "config", "volume", "test", "glyph72", "number_p", "number_b", "panel", "se_start", "se_timeup", "move", "bgm", "clear"];
          _this = _super.call(this, param) || this;

          var tl = require("@akashic-extension/akashic-timeline");

          var timeline = new tl.Timeline(_this);
          var timeline2 = new tl.Timeline(_this);

          _this.loaded.add(function () {
            g.game.vars.gameState = {
              score: 0
            };
            var size = 280;
            var panelNumX = 4;
            var panelNumY = 4;
            var panelSize = size / panelNumY;
            var margin = 40;
            var isDebug = false; //デバッグ用必ずfalseに
            // 何も送られてこない時は、標準の乱数生成器を使う

            var random = g.game.random;
            var isStart = false;

            _this.message.add(function (msg) {
              if (msg.data && msg.data.type === "start" && msg.data.parameters) {
                var sessionParameters = msg.data.parameters;

                if (sessionParameters.randomSeed != null) {
                  // プレイヤー間で共通の乱数生成器を生成
                  // `g.XorshiftRandomGenerator` は Akashic Engine の提供する乱数生成器実装で、 `g.game.random` と同じ型。
                  random = new g.XorshiftRandomGenerator(sessionParameters.randomSeed);
                }
              }
            }); // 配信者のIDを取得


            _this.lastJoinedPlayerId = "";
            g.game.join.add(function (ev) {
              _this.lastJoinedPlayerId = ev.player.id;
            }); // 背景

            var bg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "green",
              opacity: 0
            });

            _this.append(bg);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug) {
              bg.opacity = 1.0;
              bg.modified();
            }

            var base = new g.Pane({
              scene: _this,
              x: margin + 50,
              y: margin,
              width: size,
              height: size
            });

            _this.append(base);

            base.hide();
            var waku = new g.Sprite({
              scene: _this,
              src: _this.assets["waku"],
              x: 49,
              y: -1
            });

            _this.append(waku);

            waku.hide();
            var uiBase = new g.E({
              scene: _this
            });

            _this.append(uiBase);

            uiBase.hide(); //タイトル

            var sprTitle = new g.Sprite({
              scene: _this,
              src: _this.assets["title"],
              x: 70
            });

            _this.append(sprTitle);

            timeline.create(sprTitle, {
              modified: sprTitle.modified,
              destroyd: sprTitle.destroyed
            }).wait(5000).moveBy(-800, 0, 200).call(function () {
              bg.show();
              waku.show();
              base.show();
              uiBase.show();
              isStart = true;
              reset();
            }); //フォント生成

            var glyph = JSON.parse(_this.assets["test"].data);
            var numFont = new g.BitmapFont({
              src: _this.assets["img_numbers_n"],
              map: glyph.map,
              defaultGlyphWidth: glyph.width,
              defaultGlyphHeight: glyph.height,
              missingGlyph: glyph.missingGlyph
            });
            var numFontRed = new g.BitmapFont({
              src: _this.assets["img_numbers_n_red"],
              map: glyph.map,
              defaultGlyphWidth: glyph.width,
              defaultGlyphHeight: glyph.height,
              missingGlyph: glyph.missingGlyph
            });
            glyph = JSON.parse(_this.assets["glyph72"].data);
            var numFontP = new g.BitmapFont({
              src: _this.assets["number_p"],
              map: glyph.map,
              defaultGlyphWidth: 72,
              defaultGlyphHeight: 80
            });
            glyph = JSON.parse(_this.assets["glyph72"].data);
            var numFontB = new g.BitmapFont({
              src: _this.assets["number_b"],
              map: glyph.map,
              defaultGlyphWidth: 72,
              defaultGlyphHeight: 80
            }); //スコア

            uiBase.append(new g.Sprite({
              scene: _this,
              src: _this.assets["score"],
              x: 450,
              y: 6
            }));
            var score = 0;
            var labelScore = new g.Label({
              scene: _this,
              x: 440,
              y: 45,
              width: 32 * 6,
              fontSize: 32,
              font: numFont,
              text: "0P",
              textAlign: g.TextAlign.Right,
              widthAutoAdjust: false
            });
            uiBase.append(labelScore);
            var labelScorePlus = new g.Label({
              scene: _this,
              x: 440,
              y: 80,
              width: 32 * 6,
              fontSize: 32,
              font: numFontRed,
              text: "+1000",
              textAlign: g.TextAlign.Right,
              widthAutoAdjust: false
            });
            uiBase.append(labelScorePlus); //同時消し表示

            var labelCombo = new g.Label({
              scene: _this,
              font: numFontB,
              fontSize: 72,
              text: "4",
              x: 420,
              y: 120
            });
            uiBase.append(labelCombo);
            var sprCombo = new g.Sprite({
              scene: _this,
              src: _this.assets["combo"],
              x: 70,
              y: 20,
              width: 135,
              height: 50
            });
            labelCombo.append(sprCombo); //連鎖表示

            var labelRen = new g.Label({
              scene: _this,
              font: numFontP,
              fontSize: 72,
              text: "4",
              x: 420,
              y: 200
            });
            uiBase.append(labelRen);
            var sprRen = new g.Sprite({
              scene: _this,
              src: _this.assets["combo"],
              x: 90,
              y: 20,
              width: 135,
              height: 50,
              srcY: 50
            });
            labelRen.append(sprRen); //タイム

            uiBase.append(new g.Sprite({
              scene: _this,
              src: _this.assets["time"],
              x: 540,
              y: 320
            }));
            var labelTime = new g.Label({
              scene: _this,
              font: numFont,
              fontSize: 32,
              text: "70",
              x: 580,
              y: 323
            });
            uiBase.append(labelTime); //開始

            var sprStart = new g.Sprite({
              scene: _this,
              src: _this.assets["start"],
              x: 50,
              y: 100
            });
            uiBase.append(sprStart);
            sprStart.hide(); //終了

            var finishBase = new g.E({
              scene: _this,
              x: 0,
              y: 0
            });

            _this.append(finishBase);

            finishBase.hide();
            var finishBg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "#000000",
              opacity: 0.3
            });
            finishBase.append(finishBg);
            var sprFinish = new g.Sprite({
              scene: _this,
              src: _this.assets["finish"],
              x: 120,
              y: 100
            });
            finishBase.append(sprFinish); //最前面

            var fg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 480,
              cssColor: "#ff0000",
              opacity: 0.0
            });

            _this.append(fg); //リセットボタン


            var btnReset = new Button_1.Button(_this, ["リセット"], 500, 270, 130);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug) {
              finishBase.append(btnReset);

              btnReset.pushEvent = function () {
                reset();
              };
            } //ランキングボタン


            var btnRanking = new Button_1.Button(_this, ["ランキング"], 500, 200, 130);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug) {
              finishBase.append(btnRanking);

              btnRanking.pushEvent = function () {
                window.RPGAtsumaru.experimental.scoreboards.display(1);
              };
            } //設定ボタン


            var btnConfig = new g.Sprite({
              scene: _this,
              x: 600,
              y: 0,
              src: _this.assets["config"],
              touchable: true
            });

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug) {
              _this.append(btnConfig);
            } //設定画面


            var config = new Config_1.Config(_this, 380, 40);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug) {
              _this.append(config);
            }

            config.hide();
            btnConfig.pointDown.add(function () {
              if (config.state & 1) {
                config.show();
              } else {
                config.hide();
              }
            });

            config.bgmEvent = function (num) {
              bgm.changeVolume(0.5 * num);
            };

            config.colorEvent = function (str) {
              bg.cssColor = str;
              bg.modified();
            };

            var playSound = function playSound(name) {
              _this.assets[name].play().changeVolume(config.volumes[1]);
            };

            var bgm = _this.assets["bgm"].play();

            bgm.changeVolume(0.2); //スコア加算表示

            var bkTweenScore;

            var addScore = function addScore(num) {
              if (score + num < 0) {
                num = -score;
              }

              score += num;
              timeline.create().every(function (e, p) {
                labelScore.text = "" + (score - Math.floor(num * (1 - p))) + "P";
                labelScore.invalidate();
              }, 400);
              labelScorePlus.text = "+" + num;
              labelScorePlus.invalidate();
              if (bkTweenScore) timeline2.remove(bkTweenScore);
              bkTweenScore = timeline2.create().every(function (e, p) {
                labelScorePlus.opacity = p;
                labelScorePlus.modified();
              }, 100).wait(4000).call(function () {
                labelScorePlus.opacity = 0;
                labelScorePlus.modified();
              });
              g.game.vars.gameState.score = score;
            }; //パネルの土台


            var maps = [];
            var mapX = 0;
            var mapY = 0;
            var moveState = -1;
            var waitTime = 400;
            var moveTime = 100;
            var isMoveing = false;
            var isPush = false;

            var _loop_1 = function _loop_1(y) {
              maps.push([]);

              var _loop_2 = function _loop_2(x) {
                var spr = new Map({
                  scene: _this,
                  x: panelSize * x,
                  y: panelSize * (panelNumY - y - 1),
                  width: panelSize,
                  height: panelSize,
                  cssColor: (x + y) % 2 === 0 ? "#00AA00" : "green",
                  touchable: true,
                  opacity: 0.8
                });
                base.append(spr);
                maps[y].push(spr); //押したとき

                spr.pointDown.add(function (ev) {
                  if (!isStart) return;
                  if (isMoveing) return;
                  sprSelectX.y = spr.y;
                  sprSelectX.modified();
                  sprSelectX.show();
                  sprSelectY.x = spr.x;
                  sprSelectY.modified();
                  sprSelectY.show();
                  isPush = true; //画面外にドラッグして離されたとき

                  if (moveState !== -1) {
                    moveXPanels.forEach(function (e) {
                      return e.hide();
                    });
                    panels.forEach(function (e) {
                      return e.show();
                    });
                    moveState = -1;
                  }
                }); //移動

                spr.pointMove.add(function (ev) {
                  if (!isPush || !isStart) return;
                  var mx = ev.startDelta.x;
                  var my = ev.startDelta.y; //移動方向を決める

                  if (moveState === -1) {
                    var limit = 20;

                    if (mx < -limit || mx > limit) {
                      moveState = 0;
                      sprSelectY.hide();

                      for (var xx = 0; xx < mapX; xx++) {
                        panels[maps[y][xx].num].hide();
                      } //移動用


                      for (var xx = 0; xx < mapX + 2; xx++) {
                        moveXPanels[xx].y = spr.y;
                        moveXPanels[xx].x = (xx - 1) * panelSize;
                        var num = maps[y][(xx - 1 + mapX) % mapX].num;
                        moveXPanels[xx].setNum(panels[num].num);
                        moveXPanels[xx].show();
                      }
                    } else if (my < -limit || my > limit) {
                      moveState = 1;
                      sprSelectX.hide();

                      for (var yy = 0; yy < mapY; yy++) {
                        panels[maps[yy][x].num].hide();
                      } //移動用


                      for (var yy = 0; yy < mapY + 2; yy++) {
                        moveXPanels[yy].y = (mapY - yy) * panelSize;
                        moveXPanels[yy].x = spr.x;
                        var num = maps[(yy - 1 + mapY) % mapY][x].num;
                        moveXPanels[yy].setNum(panels[num].num);
                        moveXPanels[yy].show();
                      }
                    }
                  }

                  if (moveState === 0) {
                    //移動用
                    for (var xx = 0; xx < mapX + 2; xx++) {
                      moveXPanels[xx].x = (xx - 1) * panelSize + mx % panelSize;
                      var j = mx >= 0 ? Math.floor(mx / panelSize) : Math.ceil(mx / panelSize);
                      var i = mapX - j % mapX;
                      var num = maps[y][(xx - 1 + mapX + i) % mapX].num;
                      moveXPanels[xx].setNum(panels[num].num);
                      moveXPanels[xx].show();
                    }
                  }

                  if (moveState === 1) {
                    //移動用
                    for (var yy = 0; yy < mapY + 2; yy++) {
                      moveXPanels[yy].y = (mapY - yy) * panelSize + my % panelSize;
                      var j = -my >= 0 ? Math.floor(-my / panelSize) : Math.ceil(-my / panelSize);
                      var i = mapY - j % mapY;
                      var num = maps[(yy - 1 + mapY + i) % mapY][x].num;
                      moveXPanels[yy].setNum(panels[num].num);
                      moveXPanels[yy].show();
                    }
                  }
                }); //離したとき

                spr.pointUp.add(function (ev) {
                  if (!isPush || !isStart) return;
                  isPush = false; //移動を確定させる

                  if (moveState === 0) {
                    var arr = [];

                    for (var xx = 0; xx < mapX; xx++) {
                      arr.push(maps[y][xx].num);
                    }

                    var n = ev.startDelta.x + panelSize / 2;
                    var num = Math.floor(n / panelSize) + mapX;

                    for (var xx = 0; xx < mapX; xx++) {
                      var dx = (num + xx) % mapX;
                      maps[y][dx].num = arr[xx];
                      var panel = panels[maps[y][dx].num];
                      panel.x = maps[y][dx].x;
                      panel.y = maps[y][dx].y;
                      panel.modified();
                    }

                    for (var xx = 0; xx < mapX; xx++) {
                      panels[maps[y][xx].num].show();
                    } //移動用スプライトを非表示


                    for (var xx = 0; xx < mapX + 2; xx++) {
                      moveXPanels[xx].hide();
                    }

                    sprSelectX.hide();
                  }

                  if (moveState === 1) {
                    var arr = [];

                    for (var yy = 0; yy < mapY; yy++) {
                      arr.push(maps[yy][x].num);
                    }

                    var n = -ev.startDelta.y + panelSize / 2;
                    var num = Math.floor(n / panelSize) + mapY;

                    for (var yy = 0; yy < mapY; yy++) {
                      var dy = (num + yy) % mapY;
                      maps[dy][x].num = arr[yy];
                      var panel = panels[maps[dy][x].num];
                      panel.x = maps[dy][x].x;
                      panel.y = maps[dy][x].y;
                      panel.modified();
                      panel.show();
                    } //移動用スプライトを非表示


                    for (var yy = 0; yy < mapY + 2; yy++) {
                      moveXPanels[yy].hide();
                    }

                    sprSelectY.hide();
                  }

                  var moveFlg = true;
                  var moveCnt = 0;
                  var plusScore = 0;

                  var _loop_3 = function _loop_3() {
                    moveFlg = false;
                    moveCnt++;

                    if (moveState === 0) {
                      //揃っている列を探す
                      var list = [];

                      if (mapY >= 2) {
                        for (var xx = 0; xx < mapX; xx++) {
                          var flg = true;

                          for (var yy = 0; yy < mapY - 1; yy++) {
                            if (panels[maps[yy][xx].num].num !== panels[maps[yy + 1][xx].num].num) {
                              flg = false;
                              break;
                            }
                          }

                          if (flg) list.push(xx);
                        }
                      }

                      if (list.length > 1) {
                        var num_1 = list.length;
                        timeline2.create().wait((moveCnt - 1) * waitTime + (moveCnt - 2) * moveTime).call(function () {
                          labelCombo.text = "" + num_1;
                          labelCombo.invalidate();
                          labelCombo.show();
                        }).every(function (a, b) {
                          labelCombo.opacity = b;
                          labelCombo.modified();
                        }, waitTime).wait(2000).call(function () {
                          labelCombo.hide();
                        });
                      } //消す


                      if (list.length > 0) {
                        plusScore += list.length * 100 + Math.pow(list.length - 1, 2) * 100; //スコア加算
                        //効果音

                        timeline.create().wait((moveCnt - 1) * waitTime + (moveCnt - 2) * moveTime).call(function () {
                          playSound("clear");
                        });
                        var cnt = 0;
                        list.push(-1); //番兵

                        for (var xx = 0; xx < mapX; xx++) {
                          if (list[cnt] === xx) {
                            cnt++;

                            var _loop_4 = function _loop_4(yy) {
                              var num = maps[yy][xx].num;
                              var frameNum = panels[num].num + 4;
                              timeline.create().wait((moveCnt - 1) * waitTime + (moveCnt - 1) * moveTime).call(function () {
                                panels[num].frameNumber = frameNum;
                                panels[num].modified();
                              }).every(function (a, b) {
                                panels[num].opacity = b * 2.0 / 1.0;
                                panels[num].modified();
                              }, waitTime).call(function () {
                                panels[num].opacity = 1;
                                panels[num].hide();
                              });
                              panels[num].num = -1;
                              maps[yy][xx].num = -1;
                            };

                            for (var yy = 0; yy < mapY; yy++) {
                              _loop_4(yy);
                            }

                            moveFlg = true;
                          } else {
                            if (cnt > 0) {
                              for (var yy = 0; yy < mapY; yy++) {
                                var num = maps[yy][xx].num;
                                var panel = panels[num];
                                maps[yy][xx - cnt].num = num;
                                var xxx = maps[yy][xx - cnt].x;
                                var yyy = maps[yy][xx - cnt].y;
                                timeline.create(panel, {
                                  modified: panel.modified,
                                  destroyed: panel.destroyed
                                }).wait(moveCnt * waitTime + moveCnt * moveTime).moveTo(xxx, yyy, moveTime);
                                maps[yy][xx].num = -1;
                              }
                            }
                          }
                        }

                        mapX -= list.length - 1;
                      }
                    }

                    if (moveState === 1) {
                      //揃っている列を探す
                      var list = [];

                      if (mapX >= 2) {
                        for (var yy = 0; yy < mapY; yy++) {
                          var flg = true;

                          for (var xx = 0; xx < mapX - 1; xx++) {
                            if (panels[maps[yy][xx].num].num !== panels[maps[yy][xx + 1].num].num) {
                              flg = false;
                              break;
                            }
                          }

                          if (flg) list.push(yy);
                        }
                      }

                      if (list.length > 1) {
                        var num_2 = list.length;
                        timeline2.create().wait((moveCnt - 1) * waitTime + (moveCnt - 2) * moveTime).call(function () {
                          labelCombo.text = "" + num_2;
                          labelCombo.invalidate();
                          labelCombo.show();
                        }).every(function (a, b) {
                          labelCombo.opacity = b;
                          labelCombo.modified();
                        }, waitTime).wait(2000).call(function () {
                          labelCombo.hide();
                        });
                      } //消す


                      if (list.length > 0) {
                        plusScore += list.length * 100 + Math.pow(list.length - 1, 2) * 100; //スコア加算
                        //効果音

                        timeline.create().wait((moveCnt - 1) * waitTime + (moveCnt - 2) * moveTime).call(function () {
                          playSound("clear");
                        });
                        var cnt = 0;
                        list.push(-1); //番兵

                        for (var yy = 0; yy < mapY; yy++) {
                          if (list[cnt] === yy) {
                            cnt++;

                            var _loop_5 = function _loop_5(xx) {
                              var num = maps[yy][xx].num;
                              var frameNum = panels[num].num + 4;
                              timeline.create().wait((moveCnt - 1) * waitTime + (moveCnt - 1) * moveTime).call(function () {
                                panels[num].frameNumber = frameNum;
                                panels[num].modified();
                              }).every(function (a, b) {
                                panels[num].opacity = b * 2.0 / 1.0;
                                panels[num].modified();
                              }, waitTime).call(function () {
                                panels[num].opacity = 1;
                                panels[num].hide();
                              });
                              panels[num].num = -1;
                              maps[yy][xx].num = -1;
                            };

                            for (var xx = 0; xx < mapX; xx++) {
                              _loop_5(xx);
                            }

                            moveFlg = true;
                          } else {
                            if (cnt > 0) {
                              for (var xx = 0; xx < mapX; xx++) {
                                var num = maps[yy][xx].num;
                                var panel = panels[num];
                                maps[yy - cnt][xx].num = num;
                                var xxx = maps[yy - cnt][xx].x;
                                var yyy = maps[yy - cnt][xx].y;
                                timeline.create(panel, {
                                  modified: panel.modified,
                                  destroyed: panel.destroyed
                                }).wait(moveCnt * waitTime + moveCnt * moveTime).moveTo(xxx, yyy, moveTime);
                                maps[yy][xx].num = -1;
                              }
                            }
                          }
                        }

                        mapY -= list.length - 1;
                      }
                    }

                    moveState = (moveState + 1) % 2;
                  };

                  while (moveFlg) {
                    _loop_3();
                  }

                  if (moveCnt > 1) {
                    //移動アニメーション中は操作不可能にする処理
                    isMoveing = true;
                    plusScore += Math.pow(moveCnt - 2, 2) * 90; //連鎖ボーナス加算

                    timeline.create().wait((moveCnt - 1) * waitTime + (moveCnt - 2) * moveTime).call(function () {
                      addScore(plusScore);
                    });
                    timeline.create().wait(moveCnt * waitTime + (moveCnt - 1) * moveTime + 200).call(function () {
                      isMoveing = false;
                    }); //消した場所に新たに生成

                    var cntPos = 0;

                    var _loop_6 = function _loop_6(yy) {
                      var _loop_7 = function _loop_7(xx) {
                        if (maps[yy][xx].num === -1) {
                          while (panels[cntPos].num !== -1) {
                            cntPos++;
                          }

                          maps[yy][xx].num = cntPos;
                          var panel_1 = panels[cntPos];
                          timeline.create().wait(moveCnt * waitTime + (moveCnt - 1) * moveTime).call(function () {
                            panel_1.x = maps[yy][xx].x;
                            panel_1.y = -100;
                            panel_1.modified();
                            panel_1.show(); //最初から揃わないようににする処理

                            var num = random.get(0, 3);

                            if (xx > 0) {
                              while (panels[maps[yy][xx - 1].num].num === num) {
                                num = random.get(0, 3);
                              }
                            }

                            if (yy > 0) {
                              while (panels[maps[yy - 1][xx].num].num === num) {
                                num = random.get(0, 3);
                              }
                            }

                            panel_1.setNum(num);
                          }).every(function (a, b) {
                            panel_1.y = (maps[yy][xx].y + 100) * b - 100;
                            panel_1.modified();
                          }, 200);
                          cntPos++;
                        }
                      };

                      for (var xx = 0; xx < panelNumX; xx++) {
                        _loop_7(xx);
                      }
                    };

                    for (var yy = 0; yy < panelNumY; yy++) {
                      _loop_6(yy);
                    }
                  } else {
                    playSound("move");
                  }

                  var i = 1;

                  var renEvent = function renEvent() {
                    i++;

                    if (i === moveCnt) {
                      timeline2.create().wait(waitTime + moveTime + 1000).call(function () {
                        labelRen.hide();
                      });
                      return;
                    }

                    labelRen.text = "" + i;
                    labelRen.invalidate();
                    timeline2.create().every(function (a, b) {
                      labelRen.opacity = b;
                      labelRen.modified();
                    }, 100).wait(waitTime + moveTime - 100).call(renEvent);
                  };

                  if (moveCnt > 2) {
                    timeline2.create().wait(waitTime).call(function () {
                      labelRen.show();
                      renEvent();
                    });
                  }

                  moveState = -1;
                  mapX = panelNumX;
                  mapY = panelNumY; //printMap();
                });
              };

              for (var x = 0; x < panelNumX; x++) {
                _loop_2(x);
              }
            };

            for (var y = 0; y < panelNumY; y++) {
              _loop_1(y);
            }

            var printMap = function printMap() {
              var str = "";

              for (var y = panelNumY - 1; y >= 0; y--) {
                for (var x = 0; x < panelNumY; x++) {
                  str += "," + maps[y][x].num;
                }

                str += "\n";
              }

              console.log(str + "\n");
            }; //パネル


            var panels = [];

            for (var i = 0; i < panelNumX * panelNumY; i++) {
              var spr = new Panel(_this, panelSize);
              base.append(spr);
              panels.push(spr);
            } //移動用パネル


            var moveXPanels = [];

            for (var i = 0; i < panelNumX + 2; i++) {
              var spr = new Panel(_this, panelSize);
              base.append(spr);
              moveXPanels.push(spr);
            } //選択範囲


            var sprSelectX = new g.FilledRect({
              scene: _this,
              width: panelSize * panelNumX,
              height: panelSize,
              cssColor: "white",
              opacity: 0.2
            });
            base.append(sprSelectX);
            var sprSelectY = new g.FilledRect({
              scene: _this,
              width: panelSize,
              height: panelSize * panelNumY,
              cssColor: "white",
              opacity: 0.2
            });
            base.append(sprSelectY); //メインループ

            var bkTime = 0;
            var timeLimit = 70;
            var startTime = 0;

            _this.update.add(function () {
              if (!isStart) return;
              var t = timeLimit - Math.floor((Date.now() - startTime) / 1000); //終了処理

              if (t <= -1) {
                finishBase.show();
                isStart = false;
                playSound("se_timeup");
                timeline.create().wait(2200).call(function () {
                  if (typeof window !== "undefined" && window.RPGAtsumaru) {
                    window.RPGAtsumaru.experimental.scoreboards.setRecord(1, g.game.vars.gameState.score).then(function () {
                      btnRanking.show();
                      btnReset.show();
                    });
                  }

                  if (isDebug) {
                    btnRanking.show();
                    btnReset.show();
                  }
                });
                return;
              }

              labelTime.text = "" + t;
              labelTime.invalidate();

              if (bkTime !== t && t <= 5) {
                fg.opacity = 0.1;
                fg.modified();
                timeline.create().wait(500).call(function () {
                  fg.opacity = 0.0;
                  fg.modified();
                });
              }

              bkTime = t;
            }); //リセット


            var reset = function reset() {
              bkTime = 0;
              startTime = Date.now();
              isStart = true;
              score = 0;
              labelScore.text = "0P";
              finishBase.hide();
              labelScore.invalidate();
              labelScorePlus.text = "";
              labelScorePlus.invalidate();
              mapX = panelNumX;
              mapY = panelNumY;
              sprStart.show();
              timeline.create().wait(750).call(function () {
                sprStart.hide();
              });
              labelCombo.hide();
              labelRen.hide();
              btnRanking.hide();
              btnReset.hide();
              fg.opacity = 0;
              fg.modified(); //パネルの設定

              var colors = ["red", "green", "yellow", "blue"];
              var cnt = 0;

              for (var y = 0; y < panelNumY; y++) {
                for (var x = 0; x < panelNumY; x++) {
                  maps[y][x].num = cnt;
                  panels[cnt].x = maps[y][x].x;
                  panels[cnt].y = maps[y][x].y;
                  var num = random.get(0, 3);

                  if (x > 0) {
                    while (panels[maps[y][x - 1].num].num === num) {
                      num = random.get(0, 3);
                    }
                  }

                  if (y > 0) {
                    while (panels[maps[y - 1][x].num].num === num) {
                      num = random.get(0, 3);
                    }
                  }

                  panels[cnt].setNum(num);
                  panels[cnt].show();
                  cnt++;
                }
              }

              for (var i = 0; i < panelNumX + 2; i++) {
                moveXPanels[i].hide();
              }

              sprSelectX.hide();
              sprSelectY.hide();
              playSound("se_start");
              startTime = Date.now();
            };
          });

          return _this;
        }

        return MainScene;
      }(g.Scene);

      exports.MainScene = MainScene;

      var Map =
      /** @class */
      function (_super) {
        __extends(Map, _super);

        function Map(param) {
          var _this = _super.call(this, param) || this;

          _this.num = 0;
          return _this;
        }

        return Map;
      }(g.FilledRect);

      var Panel =
      /** @class */
      function (_super) {
        __extends(Panel, _super);

        function Panel(scene, panelSize) {
          var _this = _super.call(this, {
            scene: scene,
            width: panelSize,
            height: panelSize,
            src: scene.assets["panel"],
            frames: [0, 1, 2, 3, 4, 5, 6, 7]
          }) || this;

          _this.num = 0;
          _this.colors = ["red", "green", "yellow", "blue"];
          return _this;
        }

        Panel.prototype.setNum = function (num) {
          this.num = num;
          this.frameNumber = num;
          this.modified();
        };

        return Panel;
      }(g.FrameSprite);
    }, {
      "./Button": 6,
      "./Config": 7,
      "@akashic-extension/akashic-timeline": 5
    }],
    9: [function (require, module, exports) {
      "use strict";

      var MainScene_1 = require("./MainScene");

      function main(param) {
        //const DEBUG_MODE: boolean = true;
        var scene = new MainScene_1.MainScene({
          game: g.game
        });
        g.game.pushScene(scene);
      }

      module.exports = main;
    }, {
      "./MainScene": 8
    }]
  }, {}, [9])(9);
});